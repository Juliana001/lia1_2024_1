import os 
import random
import cv2
import pygame
from cvzone.FaceMeshModule import FaceMeshDetector
import cvzone
import numpy as np
import sqlite3

# Inicializar pygame
pygame.init()

# Configurar a tela do Pygame
screen_info = pygame.display.Info() # Obtem dimenssões da tela
screen_width, screen_height = screen_info.current_w, screen_info.current_h
window_width = screen_width - 100 # Redução de dimensão
window_height = screen_height - 100 # Redução de dimensão
os.environ['SDL_VIDEO_CENTERED'] = '1' # Centraliza a janela
screen = pygame.display.set_mode((window_width, window_height), pygame.RESIZABLE) # Torna a tela redimensionável
pygame.display.set_caption('Comendo Coisas Boas') # Título da Janela
icon = pygame.image.load(r'C:\Users\VandersonGoncalves\Desktop\LIAEducationalGame\Images\imagemInicio\imagemInicial.jpg')  # Use o caminho da sua imagem aqui
pygame.display.set_icon(icon)

# Conectar ao banco de dados SQLite
conn = sqlite3.connect('user_data.db')
cursor = conn.cursor()

# Criar tabela de usuários se não existir
cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                    username TEXT PRIMARY KEY,
                    score INTEGER,
                    phase INTEGER)''')

# Carregar sons
start_sound = pygame.mixer.Sound(r'C:\Users\VandersonGoncalves\Desktop\LIAEducationalGame\Audios\audioStart\cute.mp3')
eatable_sound = pygame.mixer.Sound(r'C:\Users\VandersonGoncalves\Desktop\LIAEducationalGame\Audios\audioEating\crunch.2.ogg')
game_over_sound = pygame.mixer.Sound(r'C:\Users\VandersonGoncalves\Desktop\LIAEducationalGame\Audios\audioGameOver\losetrumpet_voce_perdeu_lia2024.mp3')

# Variáveis globais
currentObject = None
pos = None
speed = None
count = None
isEatable = None
gameOver = None
phase = None
show_start_screen = True
show_score_screen = False
start_sound_played = False
game_over_sound_played = False
show_login_screen = False
username_input = ""
username = None
loggedIn = False  # Variável para rastrear o estado de login
mouthStatus = ""

def initialize_game(user):
    global currentObject, pos, speed, count, isEatable, gameOver, phase, show_start_screen, start_sound_played, game_over_sound_played, show_login_screen, username_input, username, loggedIn
    currentObject = eatables[0]
    pos = [300, 0]
    speed = 5
    count = 0
    isEatable = True
    gameOver = False
    phase = 1
    show_start_screen = False
    show_login_screen = False
    start_sound_played = False
    game_over_sound_played = False
    username_input = user
    username = user
    loggedIn = False

def update_speed():
    global speed
    if count >= 85:
        speed = 5 * 2.5  # Fase 4: 2.5x mais rápido
    elif count >= 60:
        speed = 5 * 2  # Fase 3: 2x mais rápido
    elif count >= 20:
        speed = 5 * 1.5  # Fase 2: 1,5x mais rápido
    else:
        speed = 5  # Fase 1: velocidade base

cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, window_width)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, window_height)
 
detector = FaceMeshDetector(maxFaces=1)
idList = [0, 17, 78, 292]

# Importar imagens
folderEatable = r'C:\Users\VandersonGoncalves\Desktop\LIAEducationalGame\Images\eatable'
listEatable = os.listdir(folderEatable)
eatables = [cv2.imread(f'{folderEatable}/{object}', cv2.IMREAD_UNCHANGED) for object in listEatable]

folderNonEatable = r'C:\Users\VandersonGoncalves\Desktop\LIAEducationalGame\Images\noneatable'
listNonEatable = os.listdir(folderNonEatable)
nonEatables = [cv2.imread(f'{folderNonEatable}/{object}', cv2.IMREAD_UNCHANGED) for object in listNonEatable]

def resetObject():
    global isEatable, currentObject
    pos[0] = random.randint(100, window_width - 100) # Ajuste para janela redimensionável
    pos[1] = 0
    randNo = random.randint(0, 2)  # change the ratio of eatables/ non-eatables
    if randNo == 0:
        currentObject = nonEatables[random.randint(0, len(nonEatables) - 1)]
        isEatable = False
    else:
        currentObject = eatables[random.randint(0, len(eatables) - 1)]
        isEatable = True
    return currentObject

def get_phase():
    if count >= 70:
        return 4
    elif count >= 45:
        return 3
    elif count >= 20:
        return 2
    else:
        return 1

# Reproduzir som de início continuamente até que o jogo comece
pygame.mixer.Sound.play(start_sound, loops=-1)

def clear_database():
    cursor.execute("DELETE FROM users")
    conn.commit()
    print("Dados do banco de dados limpos com sucesso.")

def print_user(db_path, username):
    try:
        # Conectar ao banco de dados
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Consulta para buscar o usuário
        cursor.execute("SELECT username, score, phase FROM users WHERE username=?", (username,))
        result = cursor.fetchone()

        # Verificar e imprimir o resultado
        if result:
            print(f"Usuário: {result[0]}")
            print(f"Pontos: {result[1]}")
            print(f"Fase: {result[2]}")
        else:
            print("Usuário não encontrado")

    except sqlite3.Error as e:
        print(f"Erro ao acessar o banco de dados: {e}")
    finally:
        # Fechar a conexão
        if conn:
            conn.close()

# Função para obter a posição centralizada
def get_centered_position(screen_width, screen_height, text_width, text_height):
    x = (screen_width - text_width) // 2
    y = (screen_height - text_height) // 2
    return x, y

# Função para desenhar um botão e retornar seu retângulo
def draw_button(screen, x, y, width, height, text):
    pygame.draw.rect(screen, (0, 127, 255), (x, y, width, height))
    font = pygame.font.Font(None, int(window_width * 0.05))  # Fonte redimensionável
    text_surface = font.render(text, True, (255, 255, 255))
    text_rect = text_surface.get_rect(center=(x + width // 2, y + height // 2))
    screen.blit(text_surface, text_rect)
    return pygame.Rect(x, y, width, height)

def draw_start_screen():
    global button_x, button_y, button_w, button_h, start_button_rect, login_button_rect, scores_button_rect
    screen.fill((222, 176, 56))

    # Fonte e texto do título
    font = pygame.font.Font(None, int(window_width * 0.1))  # Fonte redimensionável
    text = font.render("Comendo Coisas Boas", True, (0, 127, 255))
    text_x, text_y = get_centered_position(window_width, window_height, text.get_width(), text.get_height())
    screen.blit(text, (text_x, text_y - int(window_height * 0.1)))  # Ajuste verticalmente

    # Espaçamento e posição dos botões
    spacing = int(window_width * 0.02)  # Espaçamento entre os botões
    button_w, button_h = int(window_width * 0.2), int(window_height * 0.1)  # Tamanho dos botões redimensionável
    total_buttons_width = 3 * button_w + 2 * spacing
    start_x = (window_width - total_buttons_width) // 2
    start_y = (window_height - button_h) // 2 + int(window_height * 0.2)  # Ajuste verticalmente para o centro

    # Desenha os botões
    start_button_rect = draw_button(screen, start_x, start_y, button_w, button_h, "Começar")
    login_button_rect = draw_button(screen, start_x + button_w + spacing, start_y, button_w, button_h, "Login")
    scores_button_rect = draw_button(screen, start_x + 2 * (button_w + spacing), start_y, button_w, button_h, "Pontuações")

    # Carrega e redimensiona a imagem
    LogIni = pygame.image.load(r'C:\Users\VandersonGoncalves\Desktop\LIAEducationalGame\Images\imagemInicio\imagemInicial.jpg')
    new_width, new_height = int(window_width * 0.15), int(window_height * 0.15)  # Tamanho da imagem redimensionável
    LogIni = pygame.transform.scale(LogIni, (new_width, new_height))
    
    # Centraliza a imagem na tela
    image_x = (window_width - new_width) // 2
    image_y = int(window_height * 0.5)  # Ajuste a posição vertical conforme necessário
    screen.blit(LogIni, (image_x, image_y))
    
    pygame.display.flip()

def draw_login_screen():
    global username_input, login_button_rect, back_button_rect
    screen.fill((222, 176, 56))
    font = pygame.font.Font(None, int(window_width * 0.05))  # Fonte redimensionável
    text = font.render("Digite seu nome de usuário:", True, (0, 127, 255))
    text_x, text_y = get_centered_position(window_width, window_height, text.get_width(), text.get_height())
    screen.blit(text, (text_x, text_y - int(window_height * 0.1)))

    # Desenha a caixa de entrada
    input_box_width = int(window_width * 0.4)  # Tamanho da caixa de entrada redimensionável
    input_box_height = int(window_height * 0.08)
    input_box = pygame.Rect((window_width - input_box_width) // 2, text_y + int(window_height * 0.05), input_box_width, input_box_height)
    pygame.draw.rect(screen, (255, 255, 255), input_box)
    pygame.draw.rect(screen, (0, 127, 255), input_box, 2)
    input_surface = font.render(username_input, True, (0, 0, 0))
    screen.blit(input_surface, (input_box.x + 5, input_box.y + 5))

    # Desenha o botão de login
    button_w, button_h = int(window_width * 0.2), int(window_height * 0.1)  # Tamanho do botão redimensionável
    login_button_rect = draw_button(screen, (window_width - button_w) // 2, input_box.y + input_box.height + int(window_height * 0.05), button_w, button_h, "Login")
    
    # Calcula a posição do botão "Voltar" baseado na posição do botão "Login"
    back_button_y = login_button_rect.y + button_h + 20
    back_button_rect = draw_button(screen, (window_width - button_w) // 2, back_button_y, button_w, button_h, "Voltar")
    
    pygame.display.flip()


def draw_score_screen():
    global back_button_rect
    screen.fill((222, 176, 56))  # Limpar a tela com a cor de fundo

    # Título
    font = pygame.font.Font(None, 74)
    title_text = font.render("Ranking de Pontuações", True, (0, 127, 255))
    title_x, title_y = get_centered_position(window_width, window_height, title_text.get_width(), title_text.get_height())
    screen.blit(title_text, (title_x, title_y - 250))  # Ajuste verticalmente

    # Cabeçalhos da tabela
    font = pygame.font.Font(None, 50)
    headers = ["Posição", "Usuário", "Pontuação", "Fase"]

    # Defina larguras fixas para colunas com largura maior para "Usuário"
    fixed_widths = {
        "Posição": 150,
        "Usuário": 300,  # Aumente a largura para a coluna do nome de usuário
        "Pontuação": 200,
        "Fase": 150
    }

    header_widths = [fixed_widths[header] for header in headers]
    total_width = sum(header_widths) + 20 * (len(headers) - 1)  # Espaço entre colunas
    header_height = font.get_height()

    # Calcular a altura total da tabela (cabeçalhos + dados)
    cursor.execute("SELECT username, score, phase FROM users ORDER BY score DESC")
    scores = cursor.fetchall()
    total_height = header_height + 30 * (len(scores) + 1)  # Altura dos dados + cabeçalhos

    # Centralizar a tabela
    table_x = (window_width - total_width) // 2
    table_y = (window_height - total_height) // 2

    # Desenha cabeçalhos
    for i, header in enumerate(headers):
        header_text = font.render(header, True, (255, 255, 255))
        screen.blit(header_text, (table_x + sum(header_widths[:i]) + 20 * i, table_y))

    # Desenha dados
    y_offset = table_y + header_height + 10  # Ajuste para a linha abaixo dos cabeçalhos
    for idx, (username, score, phase) in enumerate(scores):
        data = [f'{idx + 1}', username, str(score), str(phase)]
        for i, value in enumerate(data):
            score_text = font.render(value, True, (255, 255, 255))
            screen.blit(score_text, (table_x + sum(header_widths[:i]) + 20 * i, y_offset))
        y_offset += 30

    # Desenha o botão "Voltar"
    button_x, button_y = get_centered_position(window_width, window_height, button_w, button_h)
    back_button_rect = draw_button(screen, button_x, y_offset + 50, button_w, button_h, "Voltar")

    pygame.display.flip()

button_x, button_y, button_w, button_h = 500, 400, 250, 100

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    success, img = cap.read()
    if not success:
        print("Falha ao capturar imagem")
        break

    if show_start_screen:
        draw_start_screen()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.VIDEORESIZE:
                window_width, window_height = event.size
                screen = pygame.display.set_mode((window_width, window_height), pygame.RESIZABLE)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = event.pos
                if start_button_rect.collidepoint(mouse_x, mouse_y):
                    initialize_game(username)
                    pygame.mixer.Sound.stop(start_sound)
                elif login_button_rect.collidepoint(mouse_x, mouse_y):
                    show_start_screen = False
                    show_login_screen = True
                elif scores_button_rect.collidepoint(mouse_x, mouse_y):
                    show_start_screen = False
                    show_score_screen = True

    elif show_login_screen:
        draw_login_screen()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.VIDEORESIZE:
                window_width, window_height = event.size
                screen = pygame.display.set_mode((window_width, window_height), pygame.RESIZABLE)
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_BACKSPACE:
                    username_input = username_input[:-1]
                    print(username_input)
                elif event.key == pygame.K_RETURN:
                    username = username_input.strip()
                    print(username)

                    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
                    user = cursor.fetchone()
                    if user is None:
                        # Se o usuário não existir, cria um novo com score 0 e fase 1
                        cursor.execute('INSERT INTO users (username, score, phase) VALUES (?, ?, ?)', (username, 0, 1))
                        conn.commit()
                        print('Usuário criado com score 0 e fase 1')
                    
                    loggedIn = True
                    show_login_screen = False
                    pygame.mixer.Sound.stop(start_sound)
                    initialize_game(username_input.strip())
                else:
                    username_input += event.unicode
                    print(username)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = event.pos
                if login_button_rect.collidepoint(mouse_x, mouse_y):
                    username = username_input.strip()
                    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
                    user = cursor.fetchone()
                    print(username)
                    
                    if user is None:
                        # Se o usuário não existir, cria um novo com score 0 e fase 1
                        cursor.execute('INSERT INTO users (username, score, phase) VALUES (?, ?, ?)', (username, 0, 1))
                        conn.commit()
                        print('Usuário criado com score 0 e fase 1')
                    else:
                        # Se o usuário existir, você pode obter as informações desejadas
                        count = user[1]  # Supondo que o score esteja na segunda coluna
                        phase = user[2]  # Supondo que a fase esteja na terceira coluna
                        print('Usuário existente - score:', count, 'fase:', phase)
                    
                    loggedIn = True
                    show_login_screen = False
                    pygame.mixer.Sound.stop(start_sound)
                    initialize_game(username_input.strip())
                elif back_button_rect.collidepoint(mouse_x, mouse_y):
                    show_login_screen = False
                    show_start_screen = True


    elif show_score_screen:
        draw_score_screen()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.VIDEORESIZE:
                window_width, window_height = event.size
                screen = pygame.display.set_mode((window_width, window_height), pygame.RESIZABLE)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = event.pos
                if back_button_rect.collidepoint(mouse_x, mouse_y):
                    show_score_screen = False
                    show_start_screen = True

    else:
        if not gameOver:
            img, faces = detector.findFaceMesh(img, draw=False)

            pos_int = (int(pos[0]), int(pos[1]))

            img = cvzone.overlayPNG(img, currentObject, pos_int)
            pos[1] += speed

            if pos[1] > window_height:
                currentObject = resetObject()

            if faces:
                face = faces[0]

                up = face[idList[0]]
                down = face[idList[1]]

                for id in idList:
                    cv2.circle(img, face[id], 5, (222, 176, 56), 5)
                cv2.line(img, up, down, (0, 127, 255), 3)
                cv2.line(img, face[idList[2]], face[idList[3]], (0, 127, 255), 3)

                upDown, _ = detector.findDistance(face[idList[0]], face[idList[1]])
                leftRight, _ = detector.findDistance(face[idList[2]], face[idList[3]])

                cx, cy = (up[0] + down[0]) // 2, (up[1] + down[1]) // 2
                cx, cy = int(cx), int(cy)
                pos_x, pos_y = int(pos[0] + 50), int(pos[1] + 50)
                cv2.line(img, (cx, cy), (pos_x, pos_y), (0, 127, 255), 3)
                distMouthObject, _ = detector.findDistance((cx, cy), (pos_x, pos_y))
                print(distMouthObject)

                ratio = int((upDown / leftRight) * 100)
                mouthStatus = "Aberta" if ratio > 60 else "Fechada"

                if distMouthObject < 100 and ratio > 60:
                    if isEatable:
                        if username == None:
                            currentObject = resetObject()
                            count += 1
                        elif username:
                            currentObject = resetObject()
                            count += 1
                            print(f"Pontuação atualizada: {count}")  # Mensagem de depuração
                            cursor.execute('''
                                SELECT score FROM users WHERE username = ?
                            ''', (username,))
                            current_score = cursor.fetchone()
                            print(current_score)

                            
                            if count > current_score[0]:
                                cursor.execute('''
                                    UPDATE users
                                    SET score = ?, phase = ?
                                    WHERE username = ?
                                ''', (count, get_phase(), username))
                                conn.commit()
                                print(f"Pontuação atualizada: {count}")
                                update_speed()
                                pygame.mixer.Sound.play(eatable_sound)

                        #print("Pontuação salva no banco de dados")  # Mensagem de depuração
                        update_speed()
                        pygame.mixer.Sound.play(eatable_sound)
                    else:
                        gameOver = True
                        pygame.mixer.stop()
                        if not game_over_sound_played:
                            pygame.mixer.Sound.play(game_over_sound)
                            game_over_sound_played = True

            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img_rgb = np.rot90(img_rgb)
            frame = pygame.surfarray.make_surface(img_rgb).convert()

            # Ajustar a imagem da câmera para o tamanho da tela do Pygame
            frame = pygame.transform.scale(frame, (window_width, window_height))
            screen.blit(frame, (0, 0))

            font = pygame.font.Font(None, 36)
            text = font.render(f"Pontuação: {count}", True, (0, 127, 255))
            screen.blit(text, (window_width - 200, 50))
            text = font.render(f"Fase: {get_phase()}", True, (0, 127, 255))
            screen.blit(text, (window_width // 2 - 50, 50))
            text = font.render(mouthStatus, True, (0, 127, 255))
            screen.blit(text, (50, 50))
            pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False

        else:
            screen.fill((222, 176, 56))

            font = pygame.font.Font(None, 74)
            text = font.render("Você perdeu!", True, (0, 127, 255))
            text_x, text_y = get_centered_position(window_width, window_height, text.get_width(), text.get_height())
            screen.blit(text, (text_x, text_y - 100))

            button_x, button_y = get_centered_position(window_width, window_height, button_w, button_h)
            draw_button(screen, button_x, button_y, button_w, button_h, "Começar")
            draw_button(screen, button_x, button_y + button_h + 20, button_w, button_h, "Sair")

            pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.VIDEORESIZE:
                    window_width, window_height = event.size
                    screen = pygame.display.set_mode((window_width, window_height), pygame.RESIZABLE)
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        pygame.mixer.Sound.play(start_sound, loops=-1)
                        initialize_game(username_input.strip())
                        show_start_screen = True
                        gameOver = False
                        break
                    elif event.key == pygame.K_q:
                        running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_x, mouse_y = event.pos
                    if button_x <= mouse_x <= button_x + button_w and button_y <= mouse_y <= button_y + button_h:
                        initialize_game(username)
                        pygame.mixer.Sound.play(start_sound, loops=-1)
                        show_start_screen = False 
                        gameOver = False
                        break
                    elif button_x <= mouse_x <= button_x + button_w and button_y + button_h + 20 <= mouse_y <= button_y + 2 * button_h + 20:
                        running = False

# Fechar conexão com o banco de dados
conn.close()
cap.release()
cv2.destroyAllWindows()
pygame.quit()